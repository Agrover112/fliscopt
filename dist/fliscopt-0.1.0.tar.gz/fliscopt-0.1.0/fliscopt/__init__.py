from . import ga,hc,rs,sa,multiproc,chaining,base_algorithm,fitness,utils

__version__ = "0.1.0"